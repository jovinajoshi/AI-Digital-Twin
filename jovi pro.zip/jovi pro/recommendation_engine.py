"""
Recommendation Engine Module for AI Digital Twin Creator

This module provides personalized suggestions, reminders, and productivity insights
based on user behavior patterns and predictions.
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
from model_training import ActivityPredictor, HabitDetector, NLPProcessor


class RecommendationEngine:
    """Generates personalized recommendations based on user behavior."""
    
    def __init__(self, activity_predictor: ActivityPredictor = None,
                 habit_detector: HabitDetector = None,
                 nlp_processor: NLPProcessor = None):
        self.activity_predictor = activity_predictor
        self.habit_detector = habit_detector
        self.nlp_processor = nlp_processor
        self.feedback_history = []
        
    def generate_recommendations(self, user_data: pd.DataFrame,
                                user_preferences: Dict,
                                current_time: datetime = None) -> List[Dict]:
        """
        Generate personalized recommendations.
        
        Args:
            user_data: User activity data
            user_preferences: User preferences dictionary
            current_time: Current timestamp
            
        Returns:
            List of recommendation dictionaries
        """
        if current_time is None:
            current_time = datetime.now()
        
        recommendations = []
        
        # Time-based recommendations
        recommendations.extend(self._time_based_recommendations(
            user_data, user_preferences, current_time
        ))
        
        # Activity-based recommendations
        if self.activity_predictor:
            recommendations.extend(self._activity_based_recommendations(
                user_data, current_time
            ))
        
        # Habit-based recommendations
        if self.habit_detector:
            recommendations.extend(self._habit_based_recommendations(
                user_data, user_preferences
            ))
        
        # Productivity insights
        recommendations.extend(self._productivity_insights(
            user_data, user_preferences
        ))
        
        # Sort by priority/score
        recommendations = sorted(recommendations, key=lambda x: x.get('priority', 0), reverse=True)
        
        return recommendations[:10]  # Return top 10 recommendations
    
    def _time_based_recommendations(self, user_data: pd.DataFrame,
                                    user_preferences: Dict,
                                    current_time: datetime) -> List[Dict]:
        """Generate time-based recommendations."""
        recommendations = []
        current_hour = current_time.hour
        day_of_week = current_time.strftime('%A')
        
        # Morning recommendations
        if 6 <= current_hour < 12:
            if 'Morning Exercise' not in user_data[user_data['hour'] == current_hour]['activity'].values:
                recommendations.append({
                    'type': 'reminder',
                    'title': 'Morning Exercise',
                    'message': 'Based on your routine, consider morning exercise for better energy.',
                    'priority': 7,
                    'category': 'Health',
                    'suggested_time': f"{current_time.replace(hour=7, minute=0).strftime('%H:%M')}"
                })
        
        # Afternoon recommendations
        elif 12 <= current_hour < 18:
            # Check for lunch
            if 'Lunch' not in user_data[user_data['hour'].between(12, 14)]['activity'].values:
                recommendations.append({
                    'type': 'reminder',
                    'title': 'Lunch Break',
                    'message': 'Time for a lunch break to maintain your energy levels.',
                    'priority': 8,
                    'category': 'Meal',
                    'suggested_time': f"{current_time.replace(hour=13, minute=0).strftime('%H:%M')}"
                })
        
        # Evening recommendations
        elif 18 <= current_hour < 22:
            # Check for dinner
            if 'Dinner' not in user_data[user_data['hour'].between(18, 20)]['activity'].values:
                recommendations.append({
                    'type': 'reminder',
                    'title': 'Dinner Time',
                    'message': 'Consider having dinner to maintain your routine.',
                    'priority': 7,
                    'category': 'Meal',
                    'suggested_time': f"{current_time.replace(hour=19, minute=0).strftime('%H:%M')}"
                })
        
        # Weekend recommendations
        if day_of_week in ['Saturday', 'Sunday']:
            recommendations.append({
                'type': 'suggestion',
                'title': 'Weekend Activity',
                'message': 'Weekends are great for leisure activities. Consider your favorite hobbies.',
                'priority': 5,
                'category': 'Leisure'
            })
        
        return recommendations
    
    def _activity_based_recommendations(self, user_data: pd.DataFrame,
                                        current_time: datetime) -> List[Dict]:
        """Generate recommendations based on activity predictions."""
        recommendations = []
        
        try:
            # Predict next activities
            predictions = self.activity_predictor.predict_next_activities(periods=7)
            
            # Get top predicted activities
            top_activities = sorted(predictions.items(), key=lambda x: x[1], reverse=True)[:3]
            
            for activity, probability in top_activities:
                if probability > 0.1:  # Only recommend if probability > 10%
                    recommendations.append({
                        'type': 'prediction',
                        'title': f'Predicted Activity: {activity}',
                        'message': f'Based on your patterns, you\'re likely to do "{activity}" soon (probability: {probability:.1%}).',
                        'priority': int(probability * 10),
                        'category': 'Prediction',
                        'confidence': probability
                    })
        except Exception as e:
            print(f"Error in activity-based recommendations: {e}")
        
        return recommendations
    
    def _habit_based_recommendations(self, user_data: pd.DataFrame,
                                     user_preferences: Dict) -> List[Dict]:
        """Generate recommendations based on detected habits."""
        recommendations = []
        
        # Analyze activity frequency
        activity_freq = user_data['activity'].value_counts()
        top_activities = activity_freq.head(5)
        
        # Suggest maintaining good habits
        for activity, count in top_activities.items():
            if count > 10:  # Frequent activity
                recommendations.append({
                    'type': 'habit',
                    'title': f'Maintain: {activity}',
                    'message': f'You\'ve done "{activity}" {count} times. Keep up the good habit!',
                    'priority': 6,
                    'category': 'Habit'
                })
        
        # Suggest variety
        unique_activities = user_data['activity'].nunique()
        if unique_activities < 10:
            recommendations.append({
                'type': 'suggestion',
                'title': 'Try New Activities',
                'message': 'Consider trying new activities to diversify your routine.',
                'priority': 4,
                'category': 'Variety'
            })
        
        return recommendations
    
    def _productivity_insights(self, user_data: pd.DataFrame,
                               user_preferences: Dict) -> List[Dict]:
        """Generate productivity insights and recommendations."""
        recommendations = []
        
        # Analyze work vs leisure balance
        work_activities = user_data[user_data['category'] == 'Work']
        leisure_activities = user_data[user_data['category'] == 'Leisure']
        
        work_ratio = len(work_activities) / len(user_data) if len(user_data) > 0 else 0
        leisure_ratio = len(leisure_activities) / len(user_data) if len(user_data) > 0 else 0
        
        if work_ratio > 0.5:
            recommendations.append({
                'type': 'insight',
                'title': 'Work-Life Balance',
                'message': f'You spend {work_ratio:.1%} of your time on work. Consider more leisure activities.',
                'priority': 6,
                'category': 'Balance'
            })
        elif leisure_ratio > 0.5:
            recommendations.append({
                'type': 'insight',
                'title': 'Productivity Tip',
                'message': f'You spend {leisure_ratio:.1%} of your time on leisure. Balance with productive activities.',
                'priority': 5,
                'category': 'Balance'
            })
        
        # Energy level insights
        avg_energy = user_data['energy_level'].mean()
        if avg_energy < 5:
            recommendations.append({
                'type': 'insight',
                'title': 'Energy Level',
                'message': f'Your average energy level is {avg_energy:.1f}/10. Consider rest or exercise.',
                'priority': 7,
                'category': 'Health'
            })
        
        # Duration insights
        avg_duration = user_data['duration'].mean()
        if avg_duration > 90:
            recommendations.append({
                'type': 'insight',
                'title': 'Activity Duration',
                'message': f'Your average activity duration is {avg_duration:.0f} minutes. Consider shorter breaks.',
                'priority': 5,
                'category': 'Efficiency'
            })
        
        return recommendations
    
    def process_user_input(self, user_input: str) -> Dict:
        """
        Process user input and generate contextual recommendations.
        
        Args:
            user_input: User's natural language input
            
        Returns:
            Dictionary with processed input and recommendations
        """
        if self.nlp_processor is None:
            return {
                'intent': 'unknown',
                'response': 'NLP processor not available.'
            }
        
        # Process input
        processed = self.nlp_processor.process_text(user_input)
        
        # Generate response based on intent
        response = self._generate_response(processed)
        
        return {
            'intent': processed['intent'],
            'entities': processed['entities'],
            'keywords': processed['keywords'],
            'response': response,
            'sentiment': processed['sentiment']
        }
    
    def _generate_response(self, processed: Dict) -> str:
        """Generate response based on processed input."""
        intent = processed['intent']
        
        if intent == 'schedule':
            return "I can help you schedule activities. Based on your patterns, I'll suggest optimal times."
        elif intent == 'recommendation':
            return "I'll analyze your behavior and provide personalized recommendations."
        elif intent == 'query':
            return "I can show you insights about your activity patterns and habits."
        elif intent == 'update':
            return "I'll update your profile based on your feedback. This helps me learn your preferences better."
        else:
            return "I understand. How can I help you with your digital twin today?"
    
    def add_feedback(self, recommendation_id: str, feedback: str, rating: int):
        """
        Add user feedback to improve recommendations.
        
        Args:
            recommendation_id: ID of the recommendation
            feedback: User feedback text
            rating: Rating (1-5)
        """
        self.feedback_history.append({
            'recommendation_id': recommendation_id,
            'feedback': feedback,
            'rating': rating,
            'timestamp': datetime.now()
        })
    
    def get_feedback_summary(self) -> Dict:
        """Get summary of user feedback."""
        if not self.feedback_history:
            return {'total_feedback': 0, 'average_rating': 0}
        
        ratings = [f['rating'] for f in self.feedback_history]
        return {
            'total_feedback': len(self.feedback_history),
            'average_rating': np.mean(ratings),
            'positive_feedback': sum(1 for r in ratings if r >= 4),
            'negative_feedback': sum(1 for r in ratings if r <= 2)
        }
    
    def update_recommendations(self, user_data: pd.DataFrame,
                              user_preferences: Dict) -> List[Dict]:
        """
        Update recommendations based on feedback and new data.
        
        This implements the feedback loop for continuous learning.
        """
        # Get feedback summary
        feedback_summary = self.get_feedback_summary()
        
        # Adjust recommendation priorities based on feedback
        recommendations = self.generate_recommendations(user_data, user_preferences)
        
        # Boost recommendations that received positive feedback
        if feedback_summary['average_rating'] > 3.5:
            for rec in recommendations:
                if rec.get('type') in ['reminder', 'suggestion']:
                    rec['priority'] = int(rec['priority'] * 1.1)  # Boost by 10%
        
        return recommendations

