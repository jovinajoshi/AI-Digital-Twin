"""
Model Training Module for AI Digital Twin Creator

This module implements ML models for:
- Clustering (KMeans) for habit detection
- Time-series forecasting (Prophet) for activity prediction
- NLP (spaCy) for understanding user input
"""

import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from prophet import Prophet
import spacy
from typing import Dict, List, Tuple, Optional
import pickle
import warnings
warnings.filterwarnings('ignore')


class HabitDetector:
    """Detects user habits using KMeans clustering."""
    
    def __init__(self, n_clusters: int = 5):
        self.n_clusters = n_clusters
        self.kmeans = None
        self.scaler = StandardScaler()
        self.cluster_labels = None
        
    def train(self, features: pd.DataFrame) -> np.ndarray:
        """
        Train KMeans model to detect habits.
        
        Args:
            features: Feature matrix
            
        Returns:
            Cluster labels
        """
        # Scale features
        features_scaled = self.scaler.fit_transform(features)
        
        # Train KMeans
        self.kmeans = KMeans(n_clusters=self.n_clusters, random_state=42, n_init=10)
        self.cluster_labels = self.kmeans.fit_predict(features_scaled)
        
        return self.cluster_labels
    
    def get_habit_clusters(self, df: pd.DataFrame, cluster_labels: np.ndarray) -> Dict:
        """
        Analyze clusters to identify habits.
        
        Args:
            df: Original data with activities
            cluster_labels: Cluster assignments
            
        Returns:
            Dictionary describing each habit cluster
        """
        df_with_clusters = df.copy()
        df_with_clusters['cluster'] = cluster_labels
        
        habits = {}
        for cluster_id in range(self.n_clusters):
            cluster_data = df_with_clusters[df_with_clusters['cluster'] == cluster_id]
            
            if len(cluster_data) > 0:
                habits[cluster_id] = {
                    'size': len(cluster_data),
                    'common_activities': cluster_data['activity'].value_counts().head(3).to_dict(),
                    'common_categories': cluster_data['category'].value_counts().head(3).to_dict(),
                    'avg_duration': cluster_data['duration'].mean(),
                    'common_times': cluster_data['time_of_day'].value_counts().head(2).to_dict(),
                    'common_locations': cluster_data['location'].value_counts().head(2).to_dict()
                }
        
        return habits
    
    def predict_cluster(self, features: pd.DataFrame) -> np.ndarray:
        """Predict cluster for new data."""
        if self.kmeans is None:
            raise ValueError("Model not trained. Call train() first.")
        
        features_scaled = self.scaler.transform(features)
        return self.kmeans.predict(features_scaled)


class ActivityPredictor:
    """Predicts future activities using time-series forecasting."""
    
    def __init__(self):
        self.models = {}
        self.activity_counts = None
        
    def prepare_time_series(self, df: pd.DataFrame) -> Dict[str, pd.DataFrame]:
        """
        Prepare time-series data for each activity.
        
        Args:
            df: Input DataFrame with activities
            
        Returns:
            Dictionary of time-series DataFrames per activity
        """
        # Create daily activity counts
        df['date'] = pd.to_datetime(df['timestamp']).dt.date
        daily_counts = df.groupby(['date', 'activity']).size().reset_index(name='count')
        daily_counts['date'] = pd.to_datetime(daily_counts['date'])
        
        # Create time-series for each activity
        time_series = {}
        for activity in df['activity'].unique():
            activity_data = daily_counts[daily_counts['activity'] == activity].copy()
            activity_data = activity_data[['date', 'count']]
            activity_data.columns = ['ds', 'y']
            activity_data = activity_data.sort_values('ds')
            
            # Fill missing dates with 0
            date_range = pd.date_range(
                start=activity_data['ds'].min(),
                end=activity_data['ds'].max(),
                freq='D'
            )
            full_range = pd.DataFrame({'ds': date_range})
            activity_data = full_range.merge(activity_data, on='ds', how='left')
            activity_data['y'] = activity_data['y'].fillna(0)
            
            time_series[activity] = activity_data
        
        self.activity_counts = daily_counts
        return time_series
    
    def train(self, df: pd.DataFrame, top_n_activities: int = 10) -> Dict:
        """
        Train Prophet models for top activities.
        
        Args:
            df: Input DataFrame
            top_n_activities: Number of top activities to model
            
        Returns:
            Dictionary of trained models
        """
        # Get top activities
        top_activities = df['activity'].value_counts().head(top_n_activities).index.tolist()
        
        # Prepare time-series
        time_series = self.prepare_time_series(df)
        
        # Train models for top activities
        for activity in top_activities:
            if activity in time_series and len(time_series[activity]) > 7:  # Need at least 7 days
                try:
                    model = Prophet(
                        yearly_seasonality=False,
                        weekly_seasonality=True,
                        daily_seasonality=False,
                        seasonality_mode='multiplicative'
                    )
                    model.fit(time_series[activity])
                    self.models[activity] = model
                except Exception as e:
                    print(f"Error training model for {activity}: {e}")
        
        return self.models
    
    def predict(self, activity: str, periods: int = 7) -> pd.DataFrame:
        """
        Predict future activity occurrences.
        
        Args:
            activity: Activity name
            periods: Number of days to predict
            
        Returns:
            DataFrame with predictions
        """
        if activity not in self.models:
            raise ValueError(f"No model trained for activity: {activity}")
        
        future = self.models[activity].make_future_dataframe(periods=periods)
        forecast = self.models[activity].predict(future)
        
        return forecast
    
    def predict_next_activities(self, periods: int = 7) -> Dict[str, float]:
        """
        Predict which activities are likely in the next period.
        
        Args:
            periods: Number of days ahead
            
        Returns:
            Dictionary of activity predictions with probabilities
        """
        predictions = {}
        
        for activity, model in self.models.items():
            try:
                forecast = self.predict(activity, periods)
                # Get average predicted count for future period
                future_forecast = forecast.tail(periods)
                avg_prediction = future_forecast['yhat'].mean()
                predictions[activity] = max(0, avg_prediction)  # Ensure non-negative
            except Exception as e:
                print(f"Error predicting for {activity}: {e}")
        
        # Normalize to probabilities
        total = sum(predictions.values())
        if total > 0:
            predictions = {k: v/total for k, v in predictions.items()}
        
        return predictions


class NLPProcessor:
    """Processes natural language input using spaCy."""
    
    def __init__(self):
        try:
            self.nlp = spacy.load("en_core_web_sm")
        except OSError:
            print("spaCy model not found. Please run: python -m spacy download en_core_web_sm")
            self.nlp = None
    
    def process_text(self, text: str) -> Dict:
        """
        Process user text input to extract intent and entities.
        
        Args:
            text: User input text
            
        Returns:
            Dictionary with extracted information
        """
        if self.nlp is None:
            # Fallback simple processing
            return self._simple_process(text)
        
        doc = self.nlp(text.lower())
        
        # Extract entities
        entities = {ent.label_: ent.text for ent in doc.ents}
        
        # Extract keywords
        keywords = [token.lemma_ for token in doc if not token.is_stop and not token.is_punct]
        
        # Detect intent
        intent = self._detect_intent(text, keywords)
        
        # Extract time references
        time_refs = self._extract_time_references(text)
        
        return {
            'intent': intent,
            'entities': entities,
            'keywords': keywords,
            'time_references': time_refs,
            'sentiment': self._get_sentiment(text)
        }
    
    def _detect_intent(self, text: str, keywords: List[str]) -> str:
        """Detect user intent from text."""
        text_lower = text.lower()
        
        if any(word in text_lower for word in ['schedule', 'plan', 'remind', 'set']):
            return 'schedule'
        elif any(word in text_lower for word in ['suggest', 'recommend', 'what should']):
            return 'recommendation'
        elif any(word in text_lower for word in ['show', 'display', 'view', 'see']):
            return 'query'
        elif any(word in text_lower for word in ['update', 'change', 'modify']):
            return 'update'
        else:
            return 'general'
    
    def _extract_time_references(self, text: str) -> List[str]:
        """Extract time references from text."""
        time_words = ['morning', 'afternoon', 'evening', 'night', 'today', 'tomorrow', 
                     'week', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 
                     'saturday', 'sunday']
        found = [word for word in time_words if word in text.lower()]
        return found
    
    def _get_sentiment(self, text: str) -> str:
        """Simple sentiment detection."""
        positive_words = ['good', 'great', 'excellent', 'happy', 'like', 'love']
        negative_words = ['bad', 'terrible', 'hate', 'dislike', 'awful']
        
        text_lower = text.lower()
        pos_count = sum(1 for word in positive_words if word in text_lower)
        neg_count = sum(1 for word in negative_words if word in text_lower)
        
        if pos_count > neg_count:
            return 'positive'
        elif neg_count > pos_count:
            return 'negative'
        else:
            return 'neutral'
    
    def _simple_process(self, text: str) -> Dict:
        """Simple fallback processing without spaCy."""
        return {
            'intent': self._detect_intent(text, []),
            'entities': {},
            'keywords': text.lower().split(),
            'time_references': self._extract_time_references(text),
            'sentiment': self._get_sentiment(text)
        }


class ModelTrainer:
    """Main class for training all models."""
    
    def __init__(self):
        self.habit_detector = HabitDetector(n_clusters=5)
        self.activity_predictor = ActivityPredictor()
        self.nlp_processor = NLPProcessor()
        self.trained = False
    
    def train_all(self, df: pd.DataFrame, features: pd.DataFrame) -> Dict:
        """
        Train all ML models.
        
        Args:
            df: Original activity data
            features: Feature matrix
            
        Returns:
            Dictionary with training results
        """
        # Adjust number of clusters based on available data
        n_samples = len(features)
        n_clusters = self.habit_detector.n_clusters
        
        # Ensure we have enough samples for clustering
        if n_samples < n_clusters:
            # Reduce clusters to match available samples (minimum 2)
            adjusted_clusters = max(2, n_samples)
            self.habit_detector.n_clusters = adjusted_clusters
            self.habit_detector.kmeans = None  # Reset the model
        
        # Train habit detector (only if we have enough data)
        habits = {}
        cluster_labels = None
        
        if n_samples >= 2:  # Need at least 2 samples for clustering
            try:
                cluster_labels = self.habit_detector.train(features)
                habits = self.habit_detector.get_habit_clusters(df, cluster_labels)
            except Exception as e:
                print(f"Error in habit detection: {e}")
                habits = {}
                cluster_labels = None
        
        # Train activity predictor
        try:
            self.activity_predictor.train(df)
        except Exception as e:
            print(f"Error in activity prediction: {e}")
        
        self.trained = True
        
        return {
            'habits': habits,
            'cluster_labels': cluster_labels,
            'models_trained': True,
            'n_samples': n_samples,
            'n_clusters_used': self.habit_detector.n_clusters
        }
    
    def save_models(self, filepath: str):
        """Save trained models to disk."""
        if not self.trained:
            raise ValueError("Models not trained yet.")
        
        with open(filepath, 'wb') as f:
            pickle.dump({
                'habit_detector': self.habit_detector,
                'activity_predictor': self.activity_predictor
            }, f)
    
    def load_models(self, filepath: str):
        """Load trained models from disk."""
        with open(filepath, 'rb') as f:
            models = pickle.load(f)
            self.habit_detector = models['habit_detector']
            self.activity_predictor = models['activity_predictor']
            self.trained = True

