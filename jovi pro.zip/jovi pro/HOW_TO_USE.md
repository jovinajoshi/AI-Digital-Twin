# 📖 How to Use AI Digital Twin Creator - Simple Guide

## 🎯 What This Project Does (Based on Abstract)

This project creates a **virtual replica of you** (a "digital twin") that:
- ✅ **Learns** your behavior patterns (what you do, when, where)
- ✅ **Predicts** your future activities
- ✅ **Adapts** to your preferences over time
- ✅ **Recommends** personalized suggestions and reminders
- ✅ **Detects** your habits automatically
- ✅ **Understands** your natural language input

## 🚀 Quick Start Guide

### Step 1: Run the Application

1. Open a terminal/command prompt
2. Navigate to the project folder:
   ```bash
   cd "C:\jovi pro"
   ```
3. Start the app:
   ```bash
   python -m streamlit run app.py
   ```
4. Your browser will open automatically at `http://localhost:8501`

### Step 2: Add Your Activities (First Time)

1. **Click on the "➕ Add Activities" tab** (first tab at the top)

2. **Fill out the form** for each activity you did:
   - **Activity Name**: What did you do? (e.g., "Morning Exercise", "Lunch", "Coding Session")
   - **Date**: When did it happen?
   - **Time**: What time did you do it?
   - **Category**: What type? (Work, Health, Meal, Leisure, etc.)
   - **Duration**: How long? (in minutes)
   - **Energy Level**: How energetic did you feel? (1-10)
   - **Location**: Where? (Home, Office, Gym, etc.)
   - **Notes**: Any extra details (optional)

3. **Click "➕ Add Activity"** button

4. **Repeat** for more activities (add at least 10-20 for best results)

### Step 3: View Your Digital Twin Dashboard

1. **Click on "📊 Dashboard" tab** (second tab)

2. **See your insights**:
   - Total activities you've logged
   - Activity distribution charts
   - Time patterns (when you do things)
   - Your preferences and habits

### Step 4: Get Recommendations

1. **Click on "🎯 Recommendations" tab** (third tab)

2. **See personalized suggestions**:
   - Reminders (e.g., "Time for lunch")
   - Activity suggestions
   - Productivity insights
   - Work-life balance tips

3. **Give feedback**: Click 👍 or 👎 on recommendations to help it learn

### Step 5: See Predictions

1. **Click on "🔮 Predictions" tab** (fourth tab)

2. **See what you're likely to do next**:
   - Probability of future activities
   - 7-day forecast
   - Visual charts showing predictions

### Step 6: Explore Your Habits

1. **Click on "🧠 Habits" tab** (fifth tab)

2. **See detected behavior patterns**:
   - Habit clusters (groups of similar activities)
   - Common activities in each habit
   - Preferred times and locations

### Step 7: Chat with Your Digital Twin

1. **Click on "💬 Chat" tab** (sixth tab)

2. **Type questions** like:
   - "What are my favorite activities?"
   - "Show me recommendations"
   - "What should I do today?"
   - "Tell me about my habits"

3. **Get intelligent responses** based on your data

## 📝 Example: How to Use It Day by Day

### Day 1: Getting Started
1. Run the app
2. Add 5-10 activities from today
3. Explore the Dashboard to see your patterns

### Day 2-7: Building Your Twin
1. Add activities each day (5-10 per day)
2. Check Recommendations tab for suggestions
3. View Predictions to see what's likely next
4. Give feedback on recommendations (👍/👎)

### Week 2+: Using Your Twin
1. Continue adding activities
2. Use Recommendations for daily guidance
3. Check Predictions to plan ahead
4. Chat with your twin for insights
5. Review Habits to understand patterns

## 🎯 What Each Feature Does (Matching Abstract)

| Feature | What It Does | How It Works |
|---------|-------------|--------------|
| **Clustering (KMeans)** | Detects your habits | Groups similar activities together |
| **Time-Series (Prophet)** | Predicts future activities | Analyzes patterns to forecast what you'll do |
| **NLP (spaCy)** | Understands your text input | Processes natural language in Chat tab |
| **Recommendation Engine** | Suggests activities | Combines patterns, predictions, and habits |
| **Feedback Loop** | Learns from your responses | Improves recommendations based on 👍/👎 |
| **Dashboard** | Shows your virtual profile | Visualizes all your data and insights |

## 💡 Tips for Best Results

1. **Add activities regularly** - The more data, the better insights
2. **Be consistent** - Add activities around the same time each day
3. **Give feedback** - Click 👍/👎 on recommendations to help it learn
4. **Explore all tabs** - Each tab shows different insights
5. **Use Chat** - Ask questions to understand your patterns

## ❓ Common Questions

### Q: Do I need to add activities every day?
**A:** Yes, for best results. Add at least 5-10 activities per day.

### Q: What if I forget to add an activity?
**A:** That's okay! Just add it when you remember. The system learns from all data.

### Q: Can I delete activities?
**A:** Yes, use the "🗑️ Clear All Activities" button, or just add new ones to override.

### Q: How long until I see good predictions?
**A:** After 20-30 activities, you'll start seeing meaningful insights.

### Q: Is my data private?
**A:** Yes! All data stays in your browser session. It's not sent anywhere.

## 🎓 Understanding the Abstract Requirements

✅ **Virtual Replica**: Your digital twin is created from your activity data  
✅ **Learns Patterns**: Uses clustering to detect habits  
✅ **Predicts Activities**: Time-series forecasting shows future activities  
✅ **Adapts Over Time**: Feedback loop improves recommendations  
✅ **NLP Understanding**: Chat tab processes natural language  
✅ **Recommendations**: Personalized suggestions and reminders  
✅ **User Control**: You can view, add, and manage your data  

## 🚨 Troubleshooting

**Problem**: App won't start  
**Solution**: Make sure you're in the correct folder and use `python -m streamlit run app.py`

**Problem**: No recommendations showing  
**Solution**: Add more activities (at least 10-20)

**Problem**: Predictions not working  
**Solution**: Need more data (30+ activities for good predictions)

**Problem**: Chat not understanding  
**Solution**: Try simpler questions like "show recommendations" or "what are my habits"

---

**Remember**: This is YOUR digital twin - the more you use it, the smarter it gets! 🤖✨

